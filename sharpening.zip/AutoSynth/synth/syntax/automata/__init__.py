from synth.syntax.automata.dfa import DFA
from synth.syntax.automata.tree_automaton import DFTA
