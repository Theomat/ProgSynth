from synth.nlp.bert import NLPEncoder
